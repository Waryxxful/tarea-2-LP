el programa esta supuestamente terminado pero cada que intento usar funciones de consola se termina la ejecucion
de este sin hacer lo que debio hacer, puse varias flags para lograr identificar donde muere el programa,pero,
despues de un rato estar probando y viendo resulta que niuna funcion logra terminar a pesar de estar bien implementadas(eso creo)
ruego porfavor ayuda y el makefile creo que esta weno no confiar en el programador autor de este "README"
Muchas gracias