#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arbol.c"



int main() {
    Nodo *entrada = crear_nodo(NULL,"Directorio","/");
    Nodo *directorio_actual = entrada;
    printf("============Consola iniciada============");
    printf("\n");
    int largo_Mlista = 10;
    Lista *lista = crear_lista(largo_Mlista);
    insertar_lista(lista,directorio_actual);
    bool flag = true;
    while (flag == true) {
        printf("> ");
        char instruccion[128];
        char parametro1[128];   
        char parametro2[128];
        scanf("%s",instruccion);
        if (strcmp(instruccion, "mkdir") == 0) {
            scanf("%s",parametro1);
            mkdir(directorio_actual, parametro1);
        } else if (strcmp(instruccion, "cd") == 0 ) {
            Directorio *dir_buscado = (Directorio*)directorio_actual->contenido;
            directorio_actual = buscar_directorio(dir_buscado,parametro1);
        } else if (strcmp(instruccion, "touch") == 0 ) {
            scanf("%s",parametro1);
            printf("comenzo la funcion\n");
            touch(directorio_actual, parametro1);
            printf("termino la funcion\n");
        } else if (strcmp(instruccion, "write") == 0 ) {
            scanf("%s",parametro1);
            scanf("%s",parametro2);
            write(directorio_actual, parametro1, parametro2);
        } else if (strcmp(instruccion, "cat") == 0 ) {
            scanf("%s",parametro1);
            cat(directorio_actual, parametro1);
        } else if (strcmp(instruccion, "ls") == 0 ) {
            ls(directorio_actual);
        } else if (strcmp(instruccion, "ls_dir") == 0 ) {
            scanf("%s",parametro1);
            ls_dir(directorio_actual, parametro1);
        }  else if (strcmp(instruccion, "exit") == 0) {
            break;
        
        }        
        else {
            printf("Instrucción desconocida o inválida: %s\n", instruccion);
        }
  
}
return 0; 
}
