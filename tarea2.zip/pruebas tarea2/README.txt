el programa supuestamente esta terminado tengo algunos problemas con las entradas y aun no logro poder entender como implementar 
la funcion "mapdir" por lo demas todo deberia funcionar correctamente. hice mi mejor intento haciendo el make file 
pero no estoy para nada seguro de que haya quedado bien.

instrucciones de compilado:
			   introducir en la terminal las siguientes lineas: gcc -Wall main.c arbol.c -o main

y luego ejecutar el ejecutable con: ./main
los casos de prueba estan al final del pdf llamado "enunciado"



porfavor no confiar al 100% en lo que escribio el programador en este README tenga discrecion muchas gracias.